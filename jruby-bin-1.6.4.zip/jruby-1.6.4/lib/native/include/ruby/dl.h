// Stub file provided for C extensions that use it to detect MRI
